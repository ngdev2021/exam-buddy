// List of Texas P&C topics for question generation

// Added math-related category for Texas P&C insurance math
const topics = [
  // Example topics. Replace or expand as needed.
  "Risk Management",
  "Property Insurance",
  "Casualty Insurance",
  "Texas Insurance Law",
  "Policy Provisions",
  "Underwriting",
  "Claims Handling",
  "Ethics & Regulations",
  "Math Calculations"  // new category added
];

export default topics;
